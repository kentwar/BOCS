from ntbea.ntbea import  SearchSpace, Evaluator, NTupleEvolutionaryAlgorithm, NTupleLandscape, Mutator
#from ntbea.ntbeaNoisyTrap import  SearchSpace, Evaluator, NTupleEvolutionaryAlgorithm, NTupleLandscape, Mutator
