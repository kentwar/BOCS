import numpy as np
from copy import deepcopy

vector = np.array((1,2,3,4,5))

vector[[4,0]]

def f(idx,r,source_array):
    result = []
    for i in range(idx, len(source_array)):
        if r - 1 > 0:
            next_level = f(i + 1, r - 1, source_array)
            for x in next_level:
                value = [source_array[i]]
                value.extend(x)
                result.append(value)

        else:
            result.append([source_array[i]])

    return result

uniqueTuples(0,2,[0,1,2,3,4,5,6,7])

def uniqueTuples(idx,n,source_array):
    result =[]
    for i in range(0,len(source_array)):
        if n - 1 > 0:
            next_level = uniqueTuples(i + 1, n - 1, source_array)
            for x in next_level:
                value = [source_array[i]]
                value.extend(x)
                result.append(value)

        else:
            result.append([source_array[i]])
    return(result)

def getUniqueTuples(idx,n,sourcearray):
    output=[]
    result = uniqueTuples(idx,n,sourcearray)
    for tup in result:
        for x in tup:
            if x == idx:
                output.append(tup)

    return(output)

getUniqueTuples(2,2,[0,1,2,3,4,5,6,7])

Q=1
def outer(out):
    def inner(inn):
        new=out*2
        return(new)
    return(inner)

test=outer(Q)

test(2)
Q=5

Y=np.array([1,2,3,4])
Yvals=deepcopy(Y)
Yvals=Yvals-Yvals.min()
Yvals=Yvals/Yvals.max()
Yvals
