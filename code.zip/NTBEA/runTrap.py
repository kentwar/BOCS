import logging
import matplotlib.pyplot as plt
import subprocess
import numpy as np
import random
import time

from ntbea import SearchSpace, Evaluator, NTupleLandscape, NTupleEvolutionaryAlgorithm
from ntbea.common import DefaultMutator


class OneMaxSearchSpace(SearchSpace):

    def __init__(self, ndims):
        super(OneMaxSearchSpace, self).__init__("OneMax Search Space", ndims)

        # Binary data for 0 and 1
        self._search_space = np.zeros([2, self._ndims], dtype=np.bool)
        self._search_space[1, :] = True

    def get_value_at(self, idx):
        assert len(idx) == 2
        assert idx[0] < self._ndims
        assert idx[1] < 2

        return self._search_space[idx]

    def get_random_point(self):
        return np.random.choice([0, 1], size=(self._ndims))

    def get_valid_values_in_dim(self, dim):
        """
        The only valid values are 0 and 1 in all dimensions
        """
        return [0, 1]

    def get_size(self):
        return 2 ** self._ndims


class OneMaxEvaluator(Evaluator):

    def __init__(self):
        super(OneMaxEvaluator, self).__init__("Pauls OneMax Evaluator")

    def true_evaluate(self, x):
        xx=str()
        for i in x:
            xx+=str(i)
        cmd=['python', '/home/pkent/Documents/Solo Research Project/Trap/Trap.py',xx]
        output = subprocess.Popen( cmd, stdout=subprocess.PIPE ).communicate()[0]
        #print(output.decode('utf-8'))
        #print(output.decode('utf-8')[8:])
        return int(output.decode('utf-8')[8:])

    def evaluate(self, x):
        xx=str()
        noise = np.random.normal(0,1,1)
        for i in x:
            xx+=str(i)
        cmd=['python', '/home/pkent/Documents/Solo Research Project/Trap/Trap.py',xx]
        output = subprocess.Popen( cmd, stdout=subprocess.PIPE ).communicate()[0]
        output = output.decode('utf-8')[8:]

        #print(output.decode('utf-8'))
        #print(output.decode('utf-8')[8:])
        return (float(output)+noise)

def init(n,triples=False):
    logging.basicConfig(level=logging.INFO)
    max_dims = n

    # Set up the problem domain as one-max problem
    search_space = OneMaxSearchSpace(max_dims)
    evaluator = OneMaxEvaluator()

    # 1-tuple, 2-tuple, 3-tuple and N-tuple
    if triples == True:
        ## Put an alternative landscape here
        tuple_landscape = NTupleLandscape(search_space, [1,2,3, max_dims])
    else:
        tuple_landscape = NTupleLandscape(search_space, [1, 2, max_dims])
    # Set the mutator type
    mutator = DefaultMutator(search_space)

    evolutionary_algorithm = NTupleEvolutionaryAlgorithm(tuple_landscape, evaluator, search_space, mutator,
                                                         k_explore=2.0)
    return(max_dims,search_space,evaluator,tuple_landscape,mutator,evolutionary_algorithm)

if __name__ == "__main__":
    ## How many runs to compare
    runs =10
    ## How many iterations per run
    iterations = 100
    ## Length of Maxone function
    n = 20
    ARRAY=np.zeros((runs,iterations))
    TimeARRAY=np.zeros((runs))
    for i in range(runs):
        start = time.time()
        max_dims,search_space,evaluator,tuple_landscape,mutator,evolutionary_algorithm=init(n,False)
        ARRAY[i,:]=evolutionary_algorithm.run(iterations)
        finish = time.time()
        TimeARRAY=np.append(TimeARRAY,finish-start)
    plt.errorbar(range(1,iterations+1),ARRAY.mean(axis=0),xerr=0,yerr=ARRAY.std(axis=0),label='Without triples')
    plt.title('NTBEA running on MaxOne Function with n=%i averaged over %i runs' %(n,runs))
    plt.xlabel('Iterations')
    plt.ylabel('Value of Best Solution')
    plt.ylim=[0,n]
    plt.legend()
    print('Mean: ', np.mean(TimeARRAY),'Max: ', np.max(TimeARRAY),'Min: ',np.min(TimeARRAY))
    plt.show()
